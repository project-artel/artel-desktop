# artel

The command line interface for the ARTEL platform. It runs a QA agent against a
game from a terminal or from CI, without opening the console in a browser.

## Installing

The CLI is published on npm as `@project-artel/cli`, and the command it installs
is `artel`. It needs Node.js 22.12.0 or newer.

```
npm install -g @project-artel/cli@alpha
artel --version
```

Keep the `@alpha` tag. Releases go out under the `alpha` dist-tag, and `latest`
still points at the older `0.0.1-alpha.0`.

To run it without a global install, as in CI, use `npx`:

```
npx @project-artel/cli@alpha <command>
```

To let an AI coding agent such as Claude Code, Codex or Cursor install it, give
the agent this prompt. [`https://artel.kr/cli.md`](https://artel.kr/cli.md)
holds step-by-step instructions written for the agent.

```
Install the ARTEL CLI on this machine by following https://artel.kr/cli.md
```

The ARTEL skills teach an AI coding agent (Claude Code, Codex, Cursor and others)
to set up the CLI, the Unity SDK and the local MCP server, and to add cheats and
behaviors to a game. Install them into the project with the command below; add
`-g` to install for every project.

```
npx skills add project-artel/artel-skills
```

The full list of skills is in
[`https://github.com/project-artel/artel-skills`](https://github.com/project-artel/artel-skills).

## Commands

### Skill 안내 조회 추가

이 기능을 포함한 CLI에서는 로그인 없이 skill 원문과 supporting reference를 조회할 수 있습니다.

```bash
artel guide list
artel guide show artel-game-identities
artel guide show artel-cheats --reference references/compile-guard.md
artel guide show artel-unity-sdk --json
```

목록과 원문은 `artel-skills`의 같은 commit으로 고정되며 응답에 revision과 source URL을 표시합니다. 최신 branch를 자동으로 따라가지 않습니다. 조회는 SDK나 skill을 설치하지 않으며, 설치·attribute 작성·MCP 및 웹 등록 절차는 조회한 안내에서 확인합니다. 네트워크 조회가 실패하면 nonzero exit와 오류를 반환합니다.

`artel guide show artel-game-identities`는 `[ArtelMetadata]`로 선언하는 **변수 메타데이터** 안내입니다. 표시 이름은 `변수 메타데이터`(영문 `Variable metadata`)이며, 기존 topic ID는 호환성을 위해 유지합니다. 이전 `[ArtelGameIdentity]`는 deprecated 호환 이름입니다.

```
artel auth login                                        # this machine's credential
artel project create --name "My Game" --genre ACTION     # returns the new project id
artel project list                                      # ids the other commands take
artel doc upload --project <id> design.pdf              # the plan the agent reads
artel case create --project <id> --file cases.json      # what the agent should check
artel case folder create --project <id> --name Combat   # group the cases
artel case move <case ids> --project <id> --folder <id> # file them into a folder
artel scenario create --project <id> --steps steps.json # how it should check it
artel scenario delete <scenario-id>
artel run create --project <id> --name smoke            # a set of scenarios
artel run scenarios <run id> --project <id> --set <ids> # fill that set
artel game start --build ./Build/Game.exe --project <id>
artel game list --project <id>                          # ids qa run takes
artel qa run --test-run <id> --instance <id>            # start one, watch to a verdict
artel qa matrix --test-run 1,2 --slot ... --slot ...    # many, spread over builds
artel qa watch <run id>
artel qa show <run id>
artel qa list --project <id>                            # find a run you lost
artel qa diff <config> <config>                         # two configurations, compared
artel issue list --project <id>                         # what the runs found
artel map show --project <id> --build <id>              # what the agent could read
artel game logout --build ./Build/Game.exe --project <id>
artel server start                                      # the whole stack, no Docker
```

`artel <group> --help` lists the rest of each group. Every command that reports
a result also takes `--json`. In that output a key never disappears, and an
unknown value is `null`.

실행 기록이 있는 시나리오를 삭제하려면 `artel scenario delete <scenario-id> --force`를 사용하세요.
해당 시나리오의 QA 실행 기록과 발견 이슈도 영구적으로 삭제됩니다.

## Running ARTEL on this machine

`artel server` runs the whole stack — PostgreSQL, the orchestration server, the
agent server and the console — as native processes, with no Docker.

```
artel server start            # downloads the runtime bundle if missing, then detaches;
                              # prints the URL when every service is ready
artel server install          # download and verify the runtime bundle without starting
artel server status           # URL, supervisor pid and the state of each service
artel server logs orchestration --follow
artel server doctor           # runtime, version, privileges, data directory, disk, ports
artel server config           # host, port, public URL and TLS files that the next start uses
artel server stop
```

The first `start` downloads the runtime bundle for this machine (150 to 250 MB)
from GitHub Releases, checks its SHA-256 and unpacks it, showing progress on
stderr. A failed download leaves nothing half-unpacked and starts nothing.
`--no-install` fails instead of downloading. When `ARTEL_RUNTIME_DIR` points at a
runtime (the desktop app sets it), `start` uses that and never downloads.
`start --json` reports `installed: true` when this start downloaded the runtime.

The stack listens on `127.0.0.1:8088` by default (another free port when that one
is taken). The network settings live in `config.json` and are read in this order:
the flag you pass to `start`, then `config.json`, then the default. A flag you pass
is saved.

```
artel server config                                       # show them (--json too)
artel server config set --host 0.0.0.0 --port 8088       # accept other machines
artel server config set --public-url https://artel.example.com
artel server config set --tls-cert ./cert.pem --tls-key ./key.pem
artel server config set --no-tls
```

`config set` only writes `config.json`; a running stack keeps its old settings until
`artel server stop` and `artel server start`. `start` also takes `--host`, `--port`,
`--public-url`, `--tls-cert` and `--tls-key`.

With `--tls-cert` and `--tls-key` the proxy serves HTTPS (the default public URL
becomes `https://127.0.0.1:<port>`) and the files are read again on every start.
The public URL must then be `https`; an `http` one is refused with
`server_settings_invalid`. An `https` public URL in front of a plain-http proxy, such
as a tunnel, is accepted too. Whenever the public URL is `https`, session cookies
are marked `Secure`. `--host 0.0.0.0` with an `http` public URL prints a warning,
because passwords and session cookies then cross the network in plain text.

On a fresh
data directory, open the URL and sign up: the first account becomes the
administrator. Data lives in `~/.local/share/artel` (or `$XDG_DATA_HOME/artel`),
`~/Library/Application Support/ARTEL` and `%LOCALAPPDATA%\ARTEL`. PostgreSQL
refuses to run as root or from an Administrator shell, so `start` does too.

## Authenticating

The CLI takes a credential from one of two places, and the first one wins.

**`ARTEL_TOKEN`.** Set it to a CLI token issued in the console's account
settings. Use this in CI: it needs no file and no browser. An empty value counts
as unset.

**`artel auth login`.** It opens the console in a browser and stores the issued
token at `~/.artel/credentials.json` (`%USERPROFILE%\.artel\credentials.json` on
Windows). Set `ARTEL_CONFIG_DIR` to keep that file somewhere else.

By default the CLI talks to the stage deployment: the API at
`https://stage-orch.artel.kr` and the console at `https://home.stage.artel.kr`.
Point it elsewhere with `ARTEL_API_BASE_URL` (or `--api-url`) and
`ARTEL_CONSOLE_BASE_URL` (or `--console-url`). The addresses `artel auth login`
used are stored with the credential and become the default for later commands.
An API with no known console, such as `http://localhost:8080`, needs
`--console-url` too.

`artel auth status` says which credential is in use and where it came from. It
prints a fingerprint, never the token.

`artel auth logout` deletes the local file. It does not revoke the token on the
server; revoke it in the console.

## Finding project and instance ids

**`artel project list`** lists the projects this credential can see. The output
is paged; it says which `--page` holds the rest.

**`artel game list --project <id>`** lists that project's game instances and
whether each one is connected now. An instance appears only after a build with
the SDK has registered once, so an empty list usually means `artel game start`
has not run yet.

## Creating test cases

**`artel case create --project <id> --file cases.json`** creates one test case
from a JSON object, or many from a JSON array of them. Without `--file` it reads
standard input.

기본으로 검토 전 초안(`reviewStatus: DRAFT`)을 만듭니다. `--no-draft`를 붙이면
즉시 사용 가능한 `READY`로 만들고, `--draft`로 기본 동작을 명시할 수도 있습니다.
이 옵션은 파일의 모든 TC에 적용되므로 JSON 본문에는 `draft`나 `reviewStatus`를 넣지 않습니다.
실행 검증 상태(`verificationStatus`)는 두 경우 모두 `DRAFT`로 시작합니다.

저장한 초안은 `artel case update <case-id> --project <id> --file approval.json`으로
승인할 수 있습니다. `approval.json`의 내용은 `{"reviewStatus":"READY"}`입니다.
일반 본문 수정은 검토 상태를 바꾸지 않습니다. 생성과 검토 상태 변경 전에 서버의
`review-status-options`를 확인하며, 미지원 서버에는 저장 요청을 보내지 않습니다.

| Field | Required | Meaning |
| --- | --- | --- |
| `scene` | yes | the scene the case is about |
| `step` | yes | what to do |
| `expectedValue` | yes | what should be true afterwards |
| `precondition` | no | what must hold before the step |
| `folderId` | no | the folder to file it in; `--folder` fills it for items that leave it out |

```json
[{ "scene": "Title Screen", "step": "Tap New Game", "expectedValue": "The game starts" }]
```

The whole file is validated before anything is created. If any item is missing a
required field, the error names each item by index (`items[3]`) and nothing is
created, so the same file can be fixed and run again. Once validation passes, an
item the server rejects does not stop the rest; the result lists each item.

## Launching a game

**`artel game start --build <path> --project <id>`** launches the build already
signed in, waits until it registers with the server, prints the game instance
id and exits. The game keeps running. The id is what `artel qa run --instance`
takes.

- The game launches windowed. `--width` and `--height` set the window size, and
  `--fullscreen` launches it full screen.
- The game log goes to a new file under `~/.artel/logs`.
  `artel game start` passes it to the game as `-logFile` and reports the path
  only if the file exists when the game registers. Otherwise `--json` prints
  `logFilePath: null` and `logFileUnavailableReason` says why. For a Windows
  `.exe` launched from WSL the CLI hands the game the Windows form of the path.
- If the build does not register within `--timeout` seconds (default 60), or
  exits first, the error says which and names the log file.

**`artel game logout --build <path> --project <id>`** launches the build once to
clear its stored session, and waits for it to exit (`--timeout`, default 30).

## Running QA

**`artel qa run --test-run <id> --instance <id>`** starts a QA run and follows
it until the agent reaches a verdict. `--no-wait` returns right after starting.

These flags set the run's configuration. A flag you leave out is chosen by the
server, and the result shows what it chose.

| Flag | Value |
| --- | --- |
| `--model` | model id; `artel qa models` lists them |
| `--prompt-version` | prompt version |
| `--reasoning-effort` | reasoning effort for the model |
| `--arch` | agent structure as a JSON object, or `@path` to a file holding one |
| `--content-map-mode` | `on`, `frozen` or `off` |
| `--knowledge-mode` | `learning`, `frozen` or `off` |
| `--input-mode` | `virtual` (default) or `os`; fixed for the run |
| `--label` | the experiment name |

`--input-mode os` asks the SDK to send real OS keyboard and mouse input. The
backend checks SDK support and permissions before starting the run; failures
are returned as errors without switching to virtual input. No build setting is
needed. This option is available on `qa run`; `qa matrix` keeps virtual input.

**The exit code is the verdict.** `0` only when the run passed. Failed,
cancelled and unknown are all `1`. A run whose connection died before a summary
is unknown, so it never passes CI by accident. `artel qa watch` follows a run
already going and uses the same rule. `artel qa show` reads a run and always
exits `0`.

With `--json`, a following command prints the final result on stdout as one line
and the progress on stderr as one JSON object per line.

If the event stream drops, the CLI reconnects up to five times without losing
events. If it still cannot reconnect, it checks the run once more: a finished
run is reported normally, and a run still going fails with
`qa_watch_disconnected` while the run continues on the server. `--timeout
<seconds>` caps the whole wait (default one hour, `0` for no cap).

**`artel qa cancel <run id>`** stops a run and frees its game instance.

**`artel qa diff <base> <target>`** compares two configurations. Each side
selects runs by `model`, `promptVersion`, `reasoningEffort` and `arch`:

```
artel qa diff \
  'model=openai/gpt-5.6-luna,promptVersion=v15' \
  'model=openai/gpt-5.6-luna,promptVersion=v16' --project <id>
```

A field you leave out matches every value, and the matching runs are added
together. Every rate in the table shows its denominator.

## Running a matrix of configurations

**`artel qa matrix`** runs every combination of the values you list, spread over
several game builds:

```
artel qa matrix \
  --project 1 \
  --test-run 1,2 \
  --model openai/gpt-5.6-luna \
  --content-map-mode off,frozen \
  --knowledge-mode off \
  --label 2x2-local-pilot \
  --slot /path/to/BuildA/WordVenture.exe \
  --slot /path/to/BuildB/WordVenture.exe
```

That is 2 test runs × 2 content map modes = 4 runs over 2 slots.

- Comma-separated values multiply the runs. A flag with one value applies to
  every run. Pass `--model` even when you are not comparing models, so the
  server cannot pick different models within one matrix.
- `--arch` is repeated instead of comma-separated, and each value needs its own
  `"label"` field.
- `--reasoning-max-tokens` applies to every run.
- `--repeat n` runs each combination n times, because one run per combination
  cannot separate the configuration from chance.
- Each `--slot` runs one QA run at a time, and the game is relaunched for every
  run.
- **Each slot needs its own build with a different `productName`.** Two builds
  with the same `productName` register as one game instance and overwrite each
  other's saves.
- `--out <path>` writes each finished run to a file as it finishes, one JSON
  object per line. `--resume` skips the runs already in that file and runs the
  rest.
- A failed combination does not stop the others. The exit code is `0` only when
  every combination passed.

## Reading the content map

**`artel map show --project <id> --build <id>`** shows what the content map of a
build holds: scenes, scene edges, screen transitions, spec gaps, confirmed
`evidence` features, and the last scan. It says whether the build has no
`evidence` document at all or has one that is not ingested yet.

`artel doc scan` starts a scan. `--watch` follows a scan before reading, capped
by `--timeout`.

## Reading what a run found

`artel issue` handles the defects QA runs found. These are not Jira issues.

**`artel issue list --project <id>`** lists them newest first, with the run each
came from. `--status` and `--severity` filter them. When there are more, the
output prints the `--before` cursor for the next page.

**`artel issue resolve <id>`** and **`artel issue reopen <id>`** change an
issue's status.

## Before automating a run

**Do not launch the game with `-batchmode`.** The SDK captures the screen from
the back buffer, and batchmode has none. The screen capture comes back blank
with no error.

**The SDK attaches itself only to a development build.** A release build has no
SDK unless a scene places one, and a game without the SDK cannot be driven.
